﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;

namespace WindowsFormsApp1
{
   public class Emp
    {


        public string name { get; set; }
        public DateTime dob { get; set; }

        public Image image { get; set; }
        public string gender { get; set; }


        public int age { get; set; }
        public string address { get; set; }
        public List<string> skills = new List<string>();
        public string mobilenumber { get; set; }
        public string mail { get; set; }
        public string fileLoc;

    }
}
