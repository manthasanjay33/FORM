﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Image file;

       
        ListBox list;
        string filename;

        public Form1()
        {
            InitializeComponent();
            lbaddress.Visible = false;
            tbaddress.Visible = false;
            list = new ListBox();
            list.Size = new System.Drawing.Size(200, 50);
            list.Location = new System.Drawing.Point(393, 270);
            this.Controls.Add(list);

            list.MultiColumn = false;

            list.SelectionMode = SelectionMode.MultiExtended;


            list.BeginUpdate();

            list.Items.Add("JAVA");
            list.Items.Add("DOT NET");
            list.Items.Add("SQL");
            list.Items.Add("ANGULAR");
            list.Items.Add("REACT JS");
            list.Items.Add("MVC");
            list.Items.Add("ADO&ASP");

            list.EndUpdate();

            // Select three items from the ListBox.
            list.SetSelected(1, true);
            list.SetSelected(3, true);
           // list.SetSelected(5, true);

            

            //MessageBox.Show(first + "" + second);


        }

        //BUTTON FOR RESUME FILE
        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "All files (*.*)|*.*";

             filename = openFileDialog1.FileName;
            string readfile = File.ReadAllText(filename);
            
        }

        //IMAGE BUTTON SELECTION
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG (*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file = Image.FromFile(f.FileName);
                
                string filenam1 = f.FileName;
                

            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                lbaddress.Visible = true;
                tbaddress.Visible = true;
            }
            else
            {
                lbaddress.Visible = false;
                tbaddress.Visible = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Emp em = new Emp();
            em.name = tbname.Text.ToString();
            em.dob = dateTimePicker1.Value;
            em.image = file;
            em.gender = radioButton1.Checked ? radioButton1.Text : radioButton2.Text;
            em.mobilenumber = tbmobile.Text;
            em.mail = tbemail.Text;

            foreach(string s in list.SelectedItems)
            {
                em.skills.Add(s);
            }
            em.age = Convert.ToInt32(tbage.Text.ToString());

            em.address = tbaddress.Text;
            em.fileLoc = filename;
            Form2 f = new Form2(em);

            this.Hide();
            f.Show();


        }
    }
}
