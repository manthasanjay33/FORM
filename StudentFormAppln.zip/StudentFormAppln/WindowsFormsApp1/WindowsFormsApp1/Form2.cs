﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        Emp data;

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Emp e)
        {
            InitializeComponent();
            data = e;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            label12.Text = data.name;
            label13.Text = data.dob.ToShortDateString();

            label14.Text = data.address;
            label15.Text = data.age.ToString();
            label16.Text = data.mail;
            label17.Text = data.mobilenumber;
            string s = "";
            foreach(string s1 in data.skills)
            {
                s += s1;
            }
            label18.Text = s;
            label19.Text = data.fileLoc;
            pictureBox1.Image = data.image;

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("submitted successfully");
        }
    }
}
